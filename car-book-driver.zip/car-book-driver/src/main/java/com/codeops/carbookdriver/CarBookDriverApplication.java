package com.codeops.carbookdriver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarBookDriverApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarBookDriverApplication.class, args);
	}

}
