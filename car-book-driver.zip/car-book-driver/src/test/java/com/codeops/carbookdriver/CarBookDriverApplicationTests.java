package com.codeops.carbookdriver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarBookDriverApplicationTests {

	@Test
	void contextLoads() {
	}

}
