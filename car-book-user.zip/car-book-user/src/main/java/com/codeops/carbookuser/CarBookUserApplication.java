package com.codeops.carbookuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarBookUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarBookUserApplication.class, args);
	}

}
